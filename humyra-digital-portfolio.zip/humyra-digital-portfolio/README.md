# Humyra digital portfolio 

A Pen created on CodePen.

Original URL: [https://codepen.io/Saima-Affan/pen/pvjOKzb](https://codepen.io/Saima-Affan/pen/pvjOKzb).

